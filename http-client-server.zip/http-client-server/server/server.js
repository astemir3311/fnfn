const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../client')));

// ===== БАЗА ДАННЫХ КЛЮЧЕВЫХ СЛОВ =====
const keywordDatabase = {
  "javascript": [
    "https://developer.mozilla.org/ru/docs/Web/JavaScript",
    "https://learn.javascript.ru/",
    "https://nodejs.org/en/docs/"
  ],
  "python": [
    "https://docs.python.org/3/",
    "https://www.python.org/about/",
    "https://peps.python.org/"
  ],
  "html": [
    "https://developer.mozilla.org/ru/docs/Web/HTML",
    "https://html.spec.whatwg.org/",
    "https://www.w3schools.com/html/"
  ],
  "css": [
    "https://developer.mozilla.org/ru/docs/Web/CSS",
    "https://www.w3.org/Style/CSS/Overview.en.html",
    "https://css-tricks.com/"
  ],
  "nodejs": [
    "https://nodejs.org/en/docs/",
    "https://expressjs.com/",
    "https://npmjs.com/"
  ],
  "рецепт": [
    "https://www.russianfood.com/recipes/recipe.php?rid=127231",
    "https://eda.ru/recepty",
    "https://povarenok.ru/"
  ],
  "новости": [
    "https://ria.ru/",
    "https://tass.ru/",
    "https://lenta.ru/"
  ],
  "погода": [
    "https://yandex.ru/pogoda/",
    "https://www.gismeteo.ru/",
    "https://pogoda.mail.ru/"
  ],
  "кот": [
    "https://ru.wikipedia.org/wiki/%D0%9A%D0%BE%D1%88%D0%BA%D0%B0",
    "https://www.purina.ru/cats/cat-breeds",
    "https://kot-pes.com/porody-koshek/"
  ],
  "собака": [
    "https://ru.wikipedia.org/wiki/%D0%A1%D0%BE%D0%B1%D0%B0%D0%BA%D0%B0",
    "https://www.purina.ru/dogs/dog-breeds",
    "https://dogs.mednet.ru/"
  ]
};

// ===== API ENDPOINTS =====

// 1. Получить список URL по ключевому слову
app.post('/api/urls', (req, res) => {
  try {
    const { keyword } = req.body;

    if (!keyword || typeof keyword !== 'string') {
      return res.status(400).json({ 
        success: false, 
        error: 'Ключевое слово обязательно' 
      });
    }

    const normalizedKeyword = keyword.toLowerCase().trim();
    const urls = keywordDatabase[normalizedKeyword];

    if (!urls || urls.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: `Ключевое слово "${keyword}" не найдено. Доступные: ${Object.keys(keywordDatabase).join(', ')}` 
      });
    }

    res.json({ 
      success: true, 
      keyword: normalizedKeyword,
      urls: urls 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: 'Внутренняя ошибка сервера: ' + error.message 
    });
  }
});

// 2. Скачать контент по URL (с прогрессом через SSE)
app.get('/api/download', async (req, res) => {
  const { url } = req.query;

  if (!url) {
    return res.status(400).json({ 
      success: false, 
      error: 'URL обязателен' 
    });
  }

  // Проверяем валидность URL
  let targetUrl;
  try {
    targetUrl = new URL(url);
  } catch {
    return res.status(400).json({ 
      success: false, 
      error: 'Некорректный URL' 
    });
  }

  try {
    const response = await fetch(targetUrl.toString(), {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    if (!response.ok) {
      return res.status(502).json({ 
        success: false, 
        error: `Ошибка при запросе к внешнему ресурсу: ${response.status} ${response.statusText}` 
      });
    }

    const contentType = response.headers.get('content-type') || 'application/octet-stream';
    const contentLength = response.headers.get('content-length');
    const totalSize = contentLength ? parseInt(contentLength, 10) : null;

    // Устанавливаем заголовки для скачивания
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', 'attachment; filename="content"');
    res.setHeader('X-Content-Length', totalSize || 'unknown');

    // Стримим данные
    const reader = response.body;
    let downloaded = 0;

    reader.on('data', (chunk) => {
      downloaded += chunk.length;
      res.write(chunk);
    });

    reader.on('end', () => {
      res.end();
    });

    reader.on('error', (err) => {
      console.error('Ошибка стриминга:', err);
      if (!res.headersSent) {
        res.status(500).json({ success: false, error: 'Ошибка при скачивании' });
      } else {
        res.end();
      }
    });

  } catch (error) {
    console.error('Ошибка скачивания:', error);
    if (!res.headersSent) {
      res.status(500).json({ 
        success: false, 
        error: 'Не удалось скачать контент: ' + error.message 
      });
    }
  }
});

// 3. Получить прогресс скачивания (SSE)
app.get('/api/download-progress', async (req, res) => {
  const { url } = req.query;

  if (!url) {
    return res.status(400).json({ error: 'URL обязателен' });
  }

  // Настройка SSE
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    const totalSize = parseInt(response.headers.get('content-length') || '0', 10);
    const reader = response.body;
    let downloaded = 0;
    let chunks = [];

    reader.on('data', (chunk) => {
      downloaded += chunk.length;
      chunks.push(chunk);

      const progress = totalSize > 0 ? Math.round((downloaded / totalSize) * 100) : -1;

      res.write(`data: ${JSON.stringify({
        type: 'progress',
        downloaded,
        totalSize,
        progress,
        status: 'downloading'
      })}\n\n`);
    });

    reader.on('end', () => {
      const content = Buffer.concat(chunks).toString('utf-8');
      res.write(`data: ${JSON.stringify({
        type: 'complete',
        downloaded,
        totalSize,
        progress: 100,
        status: 'complete',
        content: content.substring(0, 50000) // Ограничиваем размер для LocalStorage
      })}\n\n`);
      res.end();
    });

    reader.on('error', (err) => {
      res.write(`data: ${JSON.stringify({
        type: 'error',
        error: err.message
      })}\n\n`);
      res.end();
    });

  } catch (error) {
    res.write(`data: ${JSON.stringify({
      type: 'error',
      error: error.message
    })}\n\n`);
    res.end();
  }
});

// 4. Получить список всех ключевых слов
app.get('/api/keywords', (req, res) => {
  res.json({
    success: true,
    keywords: Object.keys(keywordDatabase)
  });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Статический клиент
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/index.html'));
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
  console.log(`Доступные ключевые слова: ${Object.keys(keywordDatabase).join(', ')}`);
});
